Example programs calling HiGHS from C, C++, C#, Fortran and Python are in [`HiGHS/examples`](https://github.com/ERGO-Code/HiGHS/tree/master/examples).
