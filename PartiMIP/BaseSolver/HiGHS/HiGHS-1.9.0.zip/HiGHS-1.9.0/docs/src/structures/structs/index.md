# [Overview](@id structs-overview)

The data members of fundamental structs in HiGHS are defined in this section.

 * [HighsSolution](@ref)
 * [HighsBasis](@ref)
 * [HighsInfo](@ref)
 * [HighsLinearObjective](@ref)

Structure data members for internal use only are not documented.
