# HighsModel

A QP model is communicated via an instance of the HighsModel class

- lp\_: Instance of [HighsLp](@ref) class - LP components of the model

- hessian\_: Instance of [HighsHessian](@ref) class - Hessian matrix
